USE DBA_TOOLS
GO

CREATE OR ALTER PROCEDURE usp_updstatsqueue
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON


    DECLARE @TargetDlgHandle UNIQUEIDENTIFIER
    DECLARE @ReplyMessage VARCHAR(1000)
    DECLARE @ReplyMessageName SYSNAME 
    BEGIN TRAN; 

        RECEIVE TOP(1)
        @TargetDlgHandle=Conversation_Handle
        ,@ReplyMessage=Message_Body
        ,@ReplyMessageName=Message_Type_Name
        FROM SBTargetQueue; 


        IF @ReplyMessageName=N'//SBUpdStatsMsg/ObjectXMLRequest'
        BEGIN
            DECLARE @RplyMsg VARCHAR(1000)
            SELECT @RplyMsg =N'<ObjectXMLReply>OK</ObjectXMLReply>'; 

            SEND ON CONVERSATION @TargetDlgHandle
            MESSAGE TYPE
            [//SBUpdStatsMsg/ObjectXMLReply]
            (@RplyMsg);
            END CONVERSATION @TargetDlgHandle with cleanup;
        END 
    COMMIT TRAN;

    declare @object_xml XML

    select @object_xml=@ReplyMessage;

    if ((select object_id('tempdb.dbo.#object_list')) is not null)
    begin
        drop table #object_list;
    end;

    CREATE TABLE #object_list(
        id INT NOT NULL IDENTITY(1,1),
        CommandLogId INT NOT NULL,
        DatabaseName SYSNAME NOT NULL,
        command NVARCHAR(MAX) NOT NULL);

    WITH cte_object_xml AS(
    SELECT  
           Tbl.Col.value('DatabaseName[1]', 'sysname') as DatabaseName,  
           Tbl.Col.value('SchemaName[1]', 'sysname') as SchemaName,  
           Tbl.Col.value('ObjectName[1]', 'sysname') as ObjectName
    FROM   @object_xml.nodes('//object_xml') Tbl(Col))

    insert into #object_list(
        CommandLogId,
        DatabaseName,
        command)
    select
    b.Id,
    a.DatabaseName,
    b.Command
    from cte_object_xml as a
    join dbo.CommandLog as b
    on a.DatabaseName = b.DatabaseName
    and a.SchemaName = b.SchemaName
    and a.ObjectName = b.ObjectName

    CREATE UNIQUE CLUSTERED INDEX idx_object_list on #object_list(id);

    declare @count int, @count_max int, @command_log_id int
    declare @command NVARCHAR(MAX) 

    select @count = 1, @count_max = max(id) from #object_list

    While @count <= @count_max
    begin

    select @command_log_id = CommandLogId,  @command = 'use [' + databasename + '];' + command from #object_list where id = @count

    select @command

    BEGIN TRY  
        exec (@command)
        update dbo.CommandLog
        set EndTime = getdate()
        where id = @command_log_id
    END TRY  
    BEGIN CATCH 

    update dbo.CommandLog
    set ErrorNumber = ERROR_NUMBER(),
    ErrorMessage = ERROR_MESSAGE()
    where id = @command_log_id
    END CATCH;  

    set @count = @count + 1

    end

end;