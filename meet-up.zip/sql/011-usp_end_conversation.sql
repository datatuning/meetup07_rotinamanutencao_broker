USE DBA_TOOLS
GO

CREATE OR ALTER PROCEDURE usp_end_conversation
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON

    DECLARE @TargetDlgHandle UNIQUEIDENTIFIER
    DECLARE @ReplyMessage VARCHAR(1000)
    DECLARE @ReplyMessageName SYSNAME 
    BEGIN TRAN; 

        RECEIVE TOP(1)
        @TargetDlgHandle=Conversation_Handle
        ,@ReplyMessage=Message_Body
        ,@ReplyMessageName=Message_Type_Name
        FROM SBInitiatorQueue; 
        
        END CONVERSATION @TargetDlgHandle with cleanup;
    COMMIT TRAN;
end;