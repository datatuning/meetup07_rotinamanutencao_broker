
/*limpando as filas*/
while(1=1)
begin
    waitfor (
        receive top(1)
        conversation_group_id
        from dbo.SBTargetQueue
    ), timeout 1000;

    if (@@rowcount = 0)
        break;
end

while(1=1)
begin
    waitfor (
        receive top(1)
        conversation_group_id
        from dbo.SBInitiatorQueue
    ), timeout 1000;

    if (@@rowcount = 0)
        break;
end

declare @dialog UNIQUEIDENTIFIER
while(1=1)
begin
    
    set @dialog = NULL

    select top 1 @dialog = conversation_handle from sys.conversation_endpoints

    if (@dialog IS NULL)
        break;

    end conversation @dialog with cleanup;

end

/*verificando as filas*/
SELECT * FROM SBInitiatorQueue;
SELECT * FROM SBTargetQueue;

/*verificando quantos dialogos tenho abertos*/ 
select * from sys.conversation_groups
select * from sys.conversation_endpoints
select * from sys.dm_broker_activated_tasks
