USE StackOverflow01
GO

DROP USER [SBUpdateStats]
GO

DROP CERTIFICATE [SBUpdateStats]
GO

USE DBA_TOOLS
GO

DROP USER [SBUpdateStats]
GO

DROP CERTIFICATE [SBUpdateStats]
GO

USE master
GO

DROP CERTIFICATE [SBUpdateStats]
GO

USE DBA_TOOLS
GO

CREATE CERTIFICATE [SBUpdateStats]
      ENCRYPTION BY PASSWORD = 'P@$$w0rd'
      WITH SUBJECT = 'SBUpdateStats';
GO

ADD SIGNATURE TO OBJECT::[usp_updstatsqueue]
    BY CERTIFICATE [SBUpdateStats]
    WITH PASSWORD = 'P@$$w0rd';
GO

ADD SIGNATURE TO OBJECT::[usp_end_conversation]
    BY CERTIFICATE [SBUpdateStats]
    WITH PASSWORD = 'P@$$w0rd';
GO

/*
ALTER CERTIFICATE [SBUpdateStats]
REMOVE PRIVATE KEY;
GO
*/

CREATE USER [SBUpdateStats]
FROM CERTIFICATE [SBUpdateStats];
GO

GRANT AUTHENTICATE TO [SBUpdateStats];
GO

ALTER ROLE [db_owner]
ADD MEMBER [SBUpdateStats]
GO

BACKUP CERTIFICATE [SBUpdateStats]
TO FILE = '/mnt/stack_overflow_2019_01/stack_overflow/SBUpdateStats.CER';
GO

USE StackOverflow01
GO
create CERTIFICATE [SBUpdateStats]
from FILE = '/mnt/stack_overflow_2019_01/stack_overflow/SBUpdateStats.CER';
GO

CREATE USER [SBUpdateStats]
FROM CERTIFICATE [SBUpdateStats];
GO

GRANT AUTHENTICATE TO [SBUpdateStats];
GO

ALTER ROLE [db_owner]
ADD MEMBER [SBUpdateStats]
GO