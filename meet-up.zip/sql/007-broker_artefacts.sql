USE DBA_TOOLS
GO

/*criando mensagens e contrato*/
CREATE MESSAGE TYPE
    [//SBUpdStatsMsg/ObjectXMLRequest]
        VALIDATION=WELL_FORMED_XML;

CREATE MESSAGE TYPE
    [//SBUpdStatsMsg/ObjectXMLReply]
        VALIDATION=WELL_FORMED_XML;

CREATE CONTRACT [//SBUpdStatsMsg/ObjectXMLContract](
    [//SBUpdStatsMsg/ObjectXMLRequest]
        SENT BY INITIATOR 
    ,[//SBUpdStatsMsg/ObjectXMLReply]
        SENT BY TARGET);

/*criando filas*/
CREATE QUEUE SBInitiatorQueue;
CREATE QUEUE SBTargetQueue;

SELECT * FROM SBInitiatorQueue;
SELECT * FROM SBTargetQueue;

/*criando servi�os - endpoints*/
CREATE SERVICE [//SBUpdStatsMsg/SBInitiatorService]
    ON QUEUE SBInitiatorQueue; 

CREATE SERVICE [//SBUpdStatsMsg/SBTargetService] 
    ON QUEUE SBTargetQueue
        ([//SBUpdStatsMsg/ObjectXMLContract]);


/*enviando a primeira mensagem*/
DECLARE @InitDlgHandle UNIQUEIDENTIFIER
DECLARE @RequestMessage VARCHAR(1000) 
BEGIN TRAN 
    /*preenchendo os dados de destino*/
    BEGIN DIALOG @InitDlgHandle
        FROM SERVICE
            [//SBUpdStatsMsg/SBInitiatorService]
        TO SERVICE
            '//SBUpdStatsMsg/SBTargetService'
        ON CONTRACT
            [//SBUpdStatsMsg/ObjectXMLContract]
        WITH ENCRYPTION=OFF; 
    
    /*preparando a mensagem*/
    SELECT @RequestMessage =
        N'<object_xml>
            <schemaname>dbo</schemaname>
            <databasename>StackOverflow</databasename>
            <objectname>Badges</objectname>
        </object_xml>'; 

    /*enviando a mensagem*/
    SEND ON CONVERSATION @InitDlgHandle 
        MESSAGE TYPE
            [//SBUpdStatsMsg/ObjectXMLRequest]
                (@RequestMessage);

    SELECT @RequestMessage AS SentRequestMessage;

COMMIT TRAN 

/*verificando as filas*/
SELECT * FROM SBInitiatorQueue;
SELECT * FROM SBTargetQueue;

/*dados necess�rios para a resposta*/
DECLARE @TargetDlgHandle UNIQUEIDENTIFIER
DECLARE @ReplyMessage VARCHAR(1000)
DECLARE @ReplyMessageName Sysname 

/*recebendo a mensagem*/
BEGIN TRAN; 
    RECEIVE TOP(1)
        @TargetDlgHandle = Conversation_Handle
        ,@ReplyMessage = Message_Body
        ,@ReplyMessageName = Message_Type_Name
    FROM
        SBTargetQueue; 

    SELECT @ReplyMessage AS ReceivedRequestMessage; 

    DECLARE @RplyMsg VARCHAR(1000)
            
    SELECT @RplyMsg =N'<ObjectXMLReply>OK</ObjectXMLReply>'; 
            
    SEND ON CONVERSATION
        @TargetDlgHandle
    MESSAGE TYPE
        [//SBUpdStatsMsg/ObjectXMLReply]
            (@RplyMsg);
    END CONVERSATION 
        @TargetDlgHandle
        WITH CLEANUP; /*muito importante*/

    SELECT @RplyMsg AS SentReplyMessage; 

COMMIT TRAN;

/*verificando as filas*/
SELECT * FROM SBInitiatorQueue;
SELECT * FROM SBTargetQueue;

/*verificando quantos dialogos tenho abertos*/ 
select * from sys.conversation_groups
select * from sys.conversation_endpoints

DECLARE @TargetDlgHandle UNIQUEIDENTIFIER
DECLARE @ReplyMessage VARCHAR(1000)
DECLARE @ReplyMessageName SYSNAME 
BEGIN TRAN; 

    RECEIVE TOP(1)
    @TargetDlgHandle=Conversation_Handle
    ,@ReplyMessage=Message_Body
    ,@ReplyMessageName=Message_Type_Name
    FROM SBInitiatorQueue; 
        
    END CONVERSATION @TargetDlgHandle with cleanup;
COMMIT TRAN;


/*configurando a fila para ativa��o automatica*/
ALTER QUEUE SBTargetQueue
WITH
STATUS = ON,
ACTIVATION(
        STATUS = ON,
        PROCEDURE_NAME = usp_updstatsqueue,
        MAX_QUEUE_READERS = 4,
        EXECUTE AS OWNER)

ALTER QUEUE SBInitiatorQueue
WITH
STATUS = ON,
ACTIVATION(
    STATUS = ON,
    PROCEDURE_NAME = usp_end_conversation,
    MAX_QUEUE_READERS = 1,
    EXECUTE AS OWNER)
