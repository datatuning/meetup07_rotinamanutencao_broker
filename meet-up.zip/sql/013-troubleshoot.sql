select
    req.group_id,
	req.percent_complete as [%cmp],
	coalesce(req.session_id, ses.session_id) as [sssnd],
	coalesce(req.status, ses.status) as [stts],
	req.blocking_session_id as [blk],
	ses.login_time,
	req.start_time,
	ses.last_request_start_time,
	ses.last_request_end_time,
	convert(varchar(20), getdate() - req.start_time, 108) as ttl_time,
	db_name(req.database_id) as [db_nm],
	req.last_wait_type as [lst_wt_tp],
	req.wait_type,
	req.wait_resource,
	req.wait_time,
	ses.host_name as [hst_nm],
	ses.login_name as [lgn_nm],
	ses.program_name as [prgrm_nm], 
	req.open_transaction_count as [opn_trn],
	req.open_resultset_count as [opn_rsltst],
	req.reads as [rds],
	req.writes as [wrts],
	req.logical_reads as [lgcl_rds],
	req.cpu_time as [cpu_tm],
	req.command as [cmd],
	(SELECT
		SUBSTRING(TEXT,REQ.STATEMENT_START_OFFSET/2,
			(CASE WHEN REQ.STATEMENT_END_OFFSET = -1 THEN LEN(CONVERT(NVARCHAR(MAX), TEXT)) * 2
			ELSE REQ.STATEMENT_END_OFFSET END -REQ.STATEMENT_START_OFFSET)/2) FROM SYS.DM_EXEC_SQL_TEXT(REQ.SQL_HANDLE)) [ACTUAL_TEXT],
	(select text from sys.dm_exec_sql_text (sql_handle)) [complete_text], 
	(select query_plan from sys.dm_exec_query_plan (req.plan_handle)) as query_plan
from
	sys.dm_exec_sessions ses with(nolock)
left outer join
	sys.dm_exec_requests req with(nolock)
	on ses.session_id = req.session_id
where 
	ses.group_id > 1
	and ses.session_id <> @@SPID
order by
	ses.session_id

select
    req.group_id,
	req.percent_complete as [%cmp],
	coalesce(req.session_id, ses.session_id) as [sssnd],
	coalesce(req.status, ses.status) as [stts],
	req.blocking_session_id as [blk],
	ses.login_time,
	req.start_time,
	ses.last_request_start_time,
	ses.last_request_end_time,
	convert(varchar(20), getdate() - req.start_time, 108) as ttl_time,
	db_name(req.database_id) as [db_nm],
	req.last_wait_type as [lst_wt_tp],
	req.wait_type,
	req.wait_resource,
	req.wait_time,
	ses.host_name as [hst_nm],
	ses.login_name as [lgn_nm],
	ses.program_name as [prgrm_nm], 
	req.open_transaction_count as [opn_trn],
	req.open_resultset_count as [opn_rsltst],
	req.reads as [rds],
	req.writes as [wrts],
	req.logical_reads as [lgcl_rds],
	req.cpu_time as [cpu_tm],
	req.command as [cmd],
	(SELECT
		SUBSTRING(TEXT,REQ.STATEMENT_START_OFFSET/2,
			(CASE WHEN REQ.STATEMENT_END_OFFSET = -1 THEN LEN(CONVERT(NVARCHAR(MAX), TEXT)) * 2
			ELSE REQ.STATEMENT_END_OFFSET END -REQ.STATEMENT_START_OFFSET)/2) FROM SYS.DM_EXEC_SQL_TEXT(REQ.SQL_HANDLE)) [ACTUAL_TEXT],
	(select text from sys.dm_exec_sql_text (sql_handle)) [complete_text], 
	(select query_plan from sys.dm_exec_query_plan (req.plan_handle)) as query_plan
from
	sys.dm_exec_sessions ses with(nolock)
left outer join
	sys.dm_exec_requests req with(nolock)
	on ses.session_id = req.session_id
join
    sys.dm_broker_activated_tasks as dbat
    on dbat.spid = ses.session_id
order by
	ses.session_id

