/*
select * from sys.configurations order by name

execute sp_configure 'show advanced options', 1
go
reconfigure with override
go
execute sp_configure 'max degree of parallelism', 1
go
reconfigure with override
go

Aproximadamente 40s de execu��o
*/

use stackoverflow01;
select
'CREATE STATISTICS [' + a.name + '_' + b.name + '] ON [' + schema_name(a.schema_id) + '].[' + a.name + '] (' + b.name + ') WITH FULLSCAN' as fullscan_command,
'CREATE STATISTICS [' + a.name + '_' + b.name + '] ON [' + schema_name(a.schema_id) + '].[' + a.name + '] (' + b.name + ') WITH SAMPLE 1 ROWS;' as sample_command,
schema_name(a.schema_id) as schema_name,
a.name,
b.name
from sys.tables as a
join sys.columns as b
    on a.object_id = b.object_id
