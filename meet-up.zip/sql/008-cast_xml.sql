USE DBA_TOOLS
GO

TRUNCATE TABLE DBA_TOOLS.dbo.CommandLog;

EXECUTE
    DBA_TOOLS.dbo.IndexOptimize
        @Databases = 'StackOverflow01, StackOverflow02',
        @FragmentationLow = NULL,
        @FragmentationMedium = NULL,
        @FragmentationHigh = NULL,
        @UpdateStatistics = 'ALL',
        @StatisticsSample = 1,
        @OnlyModifiedStatistics = 'N',
        @Execute = 'N',
        @LogToTable = 'Y';

SELECT * FROM DBA_TOOLS.dbo.CommandLog;

DECLARE @object_xml XML
DECLARE @utb_xml TABLE
(
    object_xml xml
)

INSERT @utb_xml (object_xml)
SELECT
(
    SELECT databasename, schemaname,  objectname from commandlog FOR XML PATH('object_xml')
)

SELECT @object_xml=object_xml FROM @utb_xml

/*transforma a tabela inteira em um XML*/
SELECT * FROM @utb_xml

/*volta para um XML*/

SELECT  
       Tbl.Col.value('databasename[1]', 'sysname') as databasename,  
       Tbl.Col.value('schemaname[1]', 'sysname') as schemaname,  
       Tbl.Col.value('objectname[1]', 'sysname') as objectname
FROM   @object_xml.nodes('//object_xml') Tbl(Col)  
