USE DBA_TOOLS
GO

UPDATE DBO.CommandLog
SET EndTime = NULL;

IF (OBJECT_ID('tempdb.dbo.#object_list') IS NOT NULL)
BEGIN
    DROP TABLE #object_list;
END

CREATE TABLE #object_list(
    id INT NOT NULL IDENTITY(1,1),
    DatabaseName SYSNAME,
    SchemaName SYSNAME,
    ObjectName SYSNAME)

INSERT INTO #object_list(
    DatabaseName,
    SchemaName,
    ObjectName)
SELECT DISTINCT
    DatabaseName,
    SchemaName,
    ObjectName
FROM
    dbo.CommandLog
ORDER BY 
    DatabaseName,
    SchemaName,
    ObjectName

CREATE UNIQUE CLUSTERED INDEX idx_object_list ON #object_list(id);

DECLARE @count INT, @count_max INT
DECLARE @object_xml XML

SELECT @count = 1, @count_max = max(id) FROM #object_list

WHILE @count <= @count_max
BEGIN

    SELECT @object_xml = cast((
        SELECT DatabaseName, SchemaName, ObjectName FROM #object_list WHERE id = @count FOR XML PATH('object_xml')
        ) AS XML)

    DECLARE @InitDlgHandle UNIQUEIDENTIFIER
    DECLARE @RequestMessage XML 
    BEGIN TRAN 
        BEGIN DIALOG @InitDlgHandle
            FROM SERVICE
                [//SBUpdStatsMsg/SBInitiatorService]
            TO SERVICE
                '//SBUpdStatsMsg/SBTargetService'
            ON CONTRACT
                [//SBUpdStatsMsg/ObjectXMLContract]
            WITH ENCRYPTION=OFF; 

        SELECT @RequestMessage = @object_xml; 

        SEND ON CONVERSATION @InitDlgHandle 
            MESSAGE TYPE
                [//SBUpdStatsMsg/ObjectXMLRequest]
                    (@RequestMessage);
        SELECT @RequestMessage AS SentRequestMessage;
    COMMIT TRAN

    SET @count = @count + 1
END


/*verificando as filas*/
SELECT * FROM SBInitiatorQueue;
SELECT * FROM SBTargetQueue;

/*verificando quantos dialogos tenho abertos*/ 
select * from sys.conversation_groups
select * from sys.conversation_endpoints
select * from sys.dm_broker_activated_tasks

select * from DBA_TOOLS.dbo.CommandLog
