TRUNCATE TABLE DBA_TOOLS.dbo.CommandLog;

EXECUTE
    DBA_TOOLS.dbo.IndexOptimize
        @Databases = 'StackOverflow01',
        --@Databases = 'StackOverflow02',
        @FragmentationLow = NULL,
        @FragmentationMedium = NULL,
        @FragmentationHigh = NULL,
        @UpdateStatistics = 'ALL',
        @StatisticsSample = 1,
        @OnlyModifiedStatistics = 'N',
        @Execute = 'N',
        @LogToTable = 'Y';

SELECT * FROM DBA_TOOLS.dbo.CommandLog;